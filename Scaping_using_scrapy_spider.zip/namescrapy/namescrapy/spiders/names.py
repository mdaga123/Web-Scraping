# -*- coding: utf-8 -*-
import scrapy
import time
import random
from scrapy import Request


class NamesSpider(scrapy.Spider):
    name = 'names'
    allowed_domains = ['en.wikipedia.org']
    start_urls = ['https://en.wikipedia.org/wiki/Category:All-American_college_football_players']

    def parse(self, response):
        titles = response.xpath('//div[@class="mw-category-group"]//li/a/text()').extract()
        for i in titles:
            scraped_data={'Title': i}
            yield scraped_data
            
        nexturl=response.xpath('//div[@id="mw-pages"]/a/@href').extract()[1]
        if nexturl:
            time.sleep(abs(random.normalvariate(2,1)))            
            yield Request(response.urljoin(nexturl),callback=self.parse,dont_filter=True)
            
        
       
        
